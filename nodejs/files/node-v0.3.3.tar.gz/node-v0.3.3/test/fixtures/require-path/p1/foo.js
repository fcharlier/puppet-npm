require.paths.unshift(__dirname);
exports.bar = require('bar');
