
JSON.parse(undefined);

